<?php 

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class ab_slider_widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'ab_slider_widget';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Image comparison', 'ab_slider' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-before-after';
	}
    
	/**
	 * Get custom help URL.
	 *
	 * Retrieve a URL where the user can get more information about the widget.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget help URL.
	 */
	public function get_custom_help_url() {
		return 'https://sknetking9.blogspot.com/';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'basic'];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'ab_slider_widget','sk','image'];
	}

	// public function get_style_depends()
    // {
    //     wp_register_style('ab_slider_widget', plugins_url('ab_slider/public/assets/css/image-comparison.css'));

    //     return [
    //         'ab_slider_widget',
    //     ];
    // }
    //  public function get_script_depends()
    //  {
    //      wp_register_script('ab_slider_widget', plugins_url('ab_slider/public/assets/js/image-comparison.js'));

    //      return [
    //          'ab_slider_widget',
    //      ];
    //  }





	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'ab_slider' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'pre_style',
			[
				'label' => esc_html__( 'Select Style', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => [
					'' => esc_html__( 'Default', 'ab_slider' ),
					'style1'  => esc_html__( 'Without handle', 'ab_slider' ),
					'style2' => esc_html__( 'Custom handle', 'ab_slider' ),
					'style3' => esc_html__( 'Focus styles', 'ab_slider' ),
					'style4' => esc_html__( 'Relative size', 'ab_slider' ),
				],
				
			]
		);
		$this->add_control(
			'style2_color',
			[
				'label' => esc_html__( 'Focus Color', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .style3' => 'box-shadow:0px 0px 15px 5px {{VALUE}}',
				],
				'condition' => [
					'pre_style' => 'style3',
				],
			]
		);
		$this->add_control(
			'style1_color',
			[
				'label' => esc_html__( 'Handle Color', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .style1' => '--divider-color:{{VALUE}}',
				],
				'condition' => [
					'pre_style' => 'style1',
				],
			]
		);
		$this->add_control(
			'divider_size',
			[
				'type' => \Elementor\Controls_Manager::NUMBER,
				'label' => esc_html__( 'Divider Size', 'ab_slider' ),
				'placeholder' => '6',
				'min' => 1,
				'max' => 100,
				'step' => 1,
				'default' =>6,
				'condition' => [
					'pre_style' => 'style1',
				],
			],
			
		);


		$this->add_control(
			'first_image',
			[
				'label' => esc_html__( 'Choose Image', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->add_control(
			'second_image',
			[
				'label' => esc_html__( 'Choose Image', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'more_options',
			[
				'label' => esc_html__( 'Additional Options', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'hover_on',
			[
				'label' => esc_html__( 'slide hover', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ab_slider' ),
				'label_off' => esc_html__( 'Hide', 'ab_slider' ),
				'return_value' => 'true',
				'default' => 'false',
			]
		);
		$this->add_control(
			'vertical_OnOff',
			[
				'label' => esc_html__( 'Vertical Direction', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'ab_slider' ),
				'label_off' => esc_html__( 'Hide', 'ab_slider' ),
				'return_value' => 'direction="vertical"',
				'default' => '',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style Section', 'ab_slider' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'style_tabs'
		);

		$this->add_control(
			'pt_margin',
			[
				'label' => esc_html__( 'Margin', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .sk_ab_slider_widget' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'pt_padding',
			[
				'label' => esc_html__( 'Padding', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .sk_ab_slider_widget' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'images_align',
			[
				'label' => esc_html__( 'Alignment', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'ab_slider' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'ab_slider' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'ab_slider' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .sk_ab_slider_widget' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => esc_html__( 'Background Color', 'ab_slider' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sk_ab_slider_widget' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'Border',
				'selector' => '{{WRAPPER}} .sk_ab_slider_widget',
			]
		);

$this->end_controls_section();



	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		$hover_on =$settings['hover_on']?$settings['hover_on']:"false";
	?>
<div class='sk_ab_slider_widget'>
<img-comparison-slider class="<?php echo $settings['pre_style'];?>" hover="<?php echo $hover_on;?>" <?php echo $settings['vertical_OnOff'];?> >
  <img slot="first" src="<?php echo $settings['first_image']['url']; ?>" />
  <img slot="second" src="<?php echo $settings['second_image']['url']; ?>" />
</img-comparison-slider>
</div>

<?php

	}

}

?>