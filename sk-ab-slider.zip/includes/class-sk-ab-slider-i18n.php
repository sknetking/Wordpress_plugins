<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://sknetking9.blogspot.com/
 * @since      1.0.0
 *
 * @package    Sk_Ab_Slider
 * @subpackage Sk_Ab_Slider/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Sk_Ab_Slider
 * @subpackage Sk_Ab_Slider/includes
 * @author     SK NetKing <sknetkingseo@gmail.com>
 */
class Sk_Ab_Slider_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'sk-ab-slider',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
