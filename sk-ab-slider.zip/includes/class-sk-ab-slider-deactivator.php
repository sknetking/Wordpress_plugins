<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://sknetking9.blogspot.com/
 * @since      1.0.0
 *
 * @package    Sk_Ab_Slider
 * @subpackage Sk_Ab_Slider/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Sk_Ab_Slider
 * @subpackage Sk_Ab_Slider/includes
 * @author     SK NetKing <sknetkingseo@gmail.com>
 */
class Sk_Ab_Slider_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
