<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://sknetking9.blogspot.com/
 * @since      1.0.0
 *
 * @package    Sk_Ab_Slider
 * @subpackage Sk_Ab_Slider/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
