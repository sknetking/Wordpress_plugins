jQuery(document).ready(function($) {
    // Bootstrap slider initialization
//     jQuery(".color-swatch").click(function(){
// 			jQuery('.swatch').removeClass('slected');
// 	   var current_color = jQuery(this).attr('data-val');
// 	   jQuery("#pa_color").val(current_color).trigger('change');
// 		 jQuery(this).addClass('slected');
// 		console.log(current_color);
// 	});
	
// 	jQuery(".img-swatch").click(function(){
// 	   var current_color = jQuery(this).attr('data-val');
// 		jQuery('.img-swatch').removeClass('slected');
// 	   	jQuery("#pa_fabric").val(current_color).trigger('change');
// 		jQuery(this).addClass('slected');
// 		console.log(current_color);
			
// 	});

// 	function dynamicSwatchSelector(clickSelector, triggerSelector, activeClass) {
// 		jQuery(clickSelector).click(function() {
// 			var currentValue = jQuery(this).attr('data-val');
// 			jQuery(clickSelector).removeClass(activeClass);
// 			jQuery(triggerSelector).val(currentValue).trigger('change');
// 			jQuery(this).addClass(activeClass);
// 			console.log(currentValue);
// 		});
// 	}


// dynamicSwatchSelector('.img-swatch', '#pa_fabric', 'slected'); 
// dynamicSwatchSelector('.color-swatch', '#pa_color', 'slected');
// dynamicSwatchSelector('.cu-pa_size', '#pa_size', 'slected');


// Usage example will work as expected with `this`:
});