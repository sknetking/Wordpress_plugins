<?php // Silence is golden
if ( ! defined( 'WPINC' ) ) {
	die;
}

//Defining plugin setting page and menu for admin

function mail_setting_register_my_custom_menu_page() {
    add_menu_page('Mail Setting', 'Mail Marketing', 'manage_options', 'mail_setting','mail_setting_call_back_function','dashicons-email-alt2',12);
    add_submenu_page('mail_setting', 'Test Mail','Test Mail','manage_options','','send_test_mail');
            
    }
    add_action( 'admin_menu', 'mail_setting_register_my_custom_menu_page' );
    
 
  
    function mail_setting_call_back_function(){
      ?> 
<div class="wrap ">
       <h1 class="page_title">Mail Setting</h1> 

        <div class="row test_from">
            <div class="col">
                      <form method="post">
						  
				
                           <h4> Send a mail to every subscriber who subscribed to our news latter.</h4>
                                   On Post Insert- <input type="checkbox" name="post_insert" value="checked" <?php echo get_option("action_post_insert");?>>  <br/>
          On Post Update - <input type="checkbox" name="post_update" value="checked" <?php echo get_option("action_post_update");?>> <br/>
						   <h4>When user update or deleted than user get mail.</h4> <br/>
        On User Delete -  <input type="checkbox" value="user_delete " name="user_delete" value="checked" <?php echo get_option("action_user_delete");?>> <br/>
  On User Update - <input type="checkbox" value="user_update " name="user_update" value="checked" <?php echo get_option("action_user_update");?>> 
							<br/><br/><br/>
							
				<button class="btn btn-primary" type="submit" name="save_option">Save Options </button>
						  <p> Notice :- Custom mail to anyone you can send by test mail. </p>
						  </form>
            </div>
            <div class="col">
                   <h2>Mail Template </h2>
                  <textarea name="post_inup" id="post_inup" cols="50" rows="10"></textarea>
                  <h2>Preview Your mail Body - </h2>
                  <div id="preview_temp"> </div>

            </div>
				
        </div>         
</div>
       <?php 
	 if(isset($_POST['save_option'])){
		 echo "<script> alert('Your Option Updated'); </script>";
		 
		update_option( 'action_post_insert',$_POST['post_insert']);
		update_option( 'action_post_update', $_POST['post_update'] );
		update_option( 'action_user_delete', $_POST['user_delete'] );
		update_option( 'action_user_update', $_POST['user_update'] );
	 }
 }

 function send_test_mail(){
  
            ?>
            <div class="wrap">
				<div class="test_form">
								<h2>Send A Test Mail -</h2>
							<form method="post">
							To -
								<input type="mail" name="send_to" id="mail"> <span>You can add multiple mail like - example@mail.com,second@mail.com </span> <br/>
							Mail Subject-
							<input type="text" name="subject" id="mail_sub">  <br/> 
							Main Body(Massage)- <br/>
								<textarea name="main_body" id="mail_body" cols="50" rows="10"> </textarea> <br>
							<input type="submit" name="submit" value="Send">

						</form>
				</div>
            </div>
<?php
 }
   
  function mail_marketing_test() {
	$sitename = get_bloginfo('name');
	$subject =$_POST['subject'];
	$to =$_POST['send_to']; //get_option('subscribers');
	$message = $_POST['main_body'].'<br/><a href="'.home_url().'">Visit Our Site</a>';
	$headers = array('Content-Type: text/html; charset=UTF-8','From: My Site Name <support@example.com>');
	
		if(isset($_POST['submit'])){
			if(wp_mail( $to, $subject, $message, $headers)){
				echo "<script> alert('Mail Send Successfully'); </script>";
			} else{
			echo "<script> alert('failed mail '); </script>";
			}
	   }
}
add_action( 'wp_loaded', 'mail_marketing_test' );
