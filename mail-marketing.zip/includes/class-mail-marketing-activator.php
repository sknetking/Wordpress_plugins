<?php

/**
 * Fired during plugin activation
 *
 * @link       https://youtube.com/sknetking
 * @since      1.0.0
 *
 * @package    Mail_Marketing
 * @subpackage Mail_Marketing/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Mail_Marketing
 * @subpackage Mail_Marketing/includes
 * @author     Shyam <sknetkingseo@gmail.com>
 */
class Mail_Marketing_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
