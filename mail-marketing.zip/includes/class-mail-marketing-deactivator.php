<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://youtube.com/sknetking
 * @since      1.0.0
 *
 * @package    Mail_Marketing
 * @subpackage Mail_Marketing/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Mail_Marketing
 * @subpackage Mail_Marketing/includes
 * @author     Shyam <sknetkingseo@gmail.com>
 */
class Mail_Marketing_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
