<?php
/**
 * Fired during plugin activation
 *
 * @link       https://youtube.com/sknetking
 * @since      1.0.0
 *
 * @package    Latest_news
 * @subpackage Latest_news/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Latest_news
 * @subpackage Latest_news/includes
 * @author     Shyam <sknetkingseo@gmail.com>
 */
class Latest_news_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		
					}
}