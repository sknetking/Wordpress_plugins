<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://youtube.com/sknetking
 * @since      1.0.0
 *
 * @package    Latest_news
 * @subpackage Latest_news/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Latest_news
 * @subpackage Latest_news/includes
 * @author     Shyam <sknetkingseo@gmail.com>
 */
class Latest_news_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
