<?php // Silence is golden
if ( ! defined( 'WPINC' ) ) {
	die;
}

//Defining plugin setting page and menu for admin

function Latest_News_register_my_custom_menu_page() {
    add_menu_page('Latest News', 'Latest News', 'manage_options', 'latest_news','','dashicons-admin-site',13);
    add_submenu_page('latest_news', 'Settings','Settings','manage_options','sky_setting','Latest_News_call_back_function');
            
    }
    add_action( 'admin_menu', 'Latest_News_register_my_custom_menu_page' );
    
 
  
    function Latest_News_call_back_function(){
      ?> 
<div class="wrap ">
       <h1 class="page_title">Setting Latest News</h1> 

        <div class="row">
            <div class="col-xl-6 col-md-6 col-sm-12">
                       <label for="select_category">
                         <p>Select a news category <select name="select_category" id="select_category" style="text-transform: uppercase;">
                         <option value="<?php echo get_option('news_category');?>" ><?php echo get_option('news_category');?></option>
                                        <option value="all">All</option>
                                        <option value="sports">Sports</option>
                                        <option value="national">India's News</option>
                                        <option value="technology">Technology</option>
                                        <option value="technology">science</option>
                                    
                                        <option value="politics">Politics</option>
                                        <option value="world">world</option>


                                    </select>
                         </p>
                       </label>
                  <p>Per day insert latest post <input type="checkbox" name="insert_daily" id="insert_daily"> </p>

                  <button id="save_setting" class="btn btn-primary">Save Setting</button>
				
				<br><br><br>
				
				<h2> [show_news_posts cat="<?php echo get_option('news_category',true);?>"] </h2>
            </div>
            <div class="col-xl-6 col-md-6 col-sm-12">
            
            <button id="insert_post" class="btn btn-primary">Insert Post</button>
<br>
				
			
			</div>
        </div>         
</div>
       
       <?php 


 }

function news_short_code($atts){
   ob_start();
     extract(shortcode_atts(array(
     	'cat'=>'All',
   ), $atts));
?>
<div class="container" id="news">
  
</div>

<script>
$.get("https://inshorts.deta.dev/news?category=<?php echo $cat;?>", function(data, status){
   for(let index=0; index<=data['data'].length;index++){
     $("#news").append('<h1 id="s_title">'+data["data"][index].title+'</h1>'); 
      $("#news").append('<span id="s_content" >'+data["data"][index].date+'</span> <br/>'); 
     $("#news").append('<img id="s_image" src="'+data["data"][index].imageUrl+'"/>');
     $("#news").append('<p id="s_content">'+data["data"][index].content+'</p>');
    $("#news").append('<a id="s_redmore"href="'+data["data"][index].readMoreUrl+'"> Read more...</a>');  
         //console.log(data['data'][index].content);
           }
    console.log(data['data']['author']);
  });
</script>
	<?php 
	 return ob_get_clean();
 } 
 add_shortcode("show_news_posts","news_short_code");